# Custom Snipping Tool

A standalone Windows screenshot utility with automatic saving to Downloads.
The original Windows Snipping Tool is not modified.

## Features

- Rectangle, freeform, window, and full virtual-screen capture.
- Automatic uniquely named PNG saves to the Windows Downloads folder.
- Clipboard image copying.
- Local Windows OCR with text copying.
- Aspect-ratio-preserving resizing that saves a copy.
- HEX and RGB screen color picking.
- Save clipboard text as a UTF-8 file.
- Notification-area operation and optional background startup.

## Requirements

64-bit Windows 10 or Windows 11 with .NET Framework 4.x and Windows
PowerShell 5.1. OCR requires an installed language supported by Windows OCR.
No external packages or cloud OCR service are used.

## Build and test

From Windows PowerShell in this project folder:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\build.ps1
```

The script compiles the application and runs image-processing self-tests.
The execution-policy option affects only that PowerShell process.
The build output is in `dist`; keep the executable and OCR script together.

```powershell
.\dist\CustomSnippingTool.exe
```

For quiet startup:

```powershell
.\dist\CustomSnippingTool.exe --background
```

To start at sign-in, create a shortcut to the executable in the Windows
Startup folder (open `shell:startup` from the Run dialog), with
`--background` as its argument. Startup is optional.

## Shortcuts and use

- **Shift + backslash:** start rectangle capture. On a US keyboard, this
  replaces typing `|` while capture shortcuts are enabled.
- **Print Screen:** start rectangle capture while the application is running.
  If another application intercepts it, use the desktop shortcut or menu.
- **Fn + Y:** only works if keyboard firmware maps it to Print Screen.
  Windows cannot normally register Fn as a keyboard modifier.
- **Escape or right-click:** cancel selection.

Open the app window to choose other capture modes and actions.
Closing the window hides it to the notification area. Double-click the tray
icon to reopen it. Right-click the tray icon and choose **Exit and restore
normal keys** to stop it. Uncheck **Enable capture shortcuts** to pause key
overrides.

Captures immediately save and copy to the clipboard. OCR and color picking
replace the clipboard contents with text. Resize preserves the original PNG.

## Limitations

- Window capture saves visible pixels within a window's bounds; it does not
  recover obscured content.
- Full-screen capture includes all monitors.
- Protected/DRM content may appear black.
- OCR has a Windows-defined maximum image dimension; resize large captures
  before extracting text.
- This version does not provide video capture, annotations, batch renaming,
  ZIP creation, or Downloads organization.

## Source and tests

- `src/CustomSnippingTool.cs`: WinForms application and image self-tests.
- `src/Read-ScreenshotText.ps1`: local Windows OCR bridge.
- `src/CustomSnippingTool.exe.manifest`: DPI-awareness and non-admin execution.
- `build.ps1`: compilation and self-test runner.

Self-tests cover rectangle cropping, off-screen bounds, freeform transparency,
aspect-ratio resizing, invalid resize rejection, unique PNG filenames, PNG
roundtripping, and Downloads detection. Hotkeys, capture overlays, clipboard
behavior, and OCR also require interactive desktop testing.

## Removal

Exit through the tray menu, remove any desktop and Startup shortcuts you
created, then remove the application folder. Saved captures are not deleted.

## GitHub upload

Create a repository named `custom-snipping-tool` in your GitHub account.
Private visibility is a reasonable starting choice. Extract this package,
then upload the contents of this project folder to the repository, including
the hidden `.gitignore` file. Do not upload screenshots or personal clipboard
files. This package contains source only, not captured images or credentials.
