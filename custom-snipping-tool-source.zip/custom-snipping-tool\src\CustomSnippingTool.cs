using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Win32;

namespace CustomSnipping
{
    internal static class Program
    {
        [STAThread]
        private static int Main(string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            if (args.Length > 0 && args[0] == "--self-test")
            {
                try { SelfTest.Run(); return 0; }
                catch (Exception ex) { File.WriteAllText(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "self-test-result.txt"), ex.ToString()); return 1; }
            }
            bool created;
            using (var mutex = new Mutex(true, @"Local\CustomSnippingTool-Shane", out created))
            {
                if (!created)
                {
                    IntPtr window = Native.FindWindow(null, MainForm.Title);
                    if (window != IntPtr.Zero) { Native.ShowWindow(window, 9); Native.SetForegroundWindow(window); }
                    return 0;
                }
                Application.ThreadException += delegate(object sender, ThreadExceptionEventArgs e)
                {
                    MessageBox.Show(e.Exception.Message, "Screenshot tool error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                };
                Application.Run(new MainForm(args.Length > 0 && args[0] == "--background"));
            }
            return 0;
        }
    }

    internal static class Images
    {
        public static string Downloads()
        {
            using (var key = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders"))
            {
                string value = key == null ? null : key.GetValue("{374DE290-123F-4565-9164-39C4925E467B}", null, RegistryValueOptions.DoNotExpandEnvironmentNames) as string;
                if (String.IsNullOrWhiteSpace(value)) throw new IOException("Windows Downloads folder is not configured.");
                string path = Environment.ExpandEnvironmentVariables(value);
                if (!Directory.Exists(path)) throw new DirectoryNotFoundException("Downloads folder does not exist: " + path);
                return path;
            }
        }

        public static string NewPath(string folder, string prefix, string extension)
        {
            return Path.Combine(folder, prefix + "_" + DateTime.Now.ToString("yyyy-MM-dd_HH-mm-ss-fff") + "_" + Guid.NewGuid().ToString("N").Substring(0, 8) + extension);
        }

        public static string Save(Bitmap image, string directory, string prefix)
        {
            string path = NewPath(directory, prefix, ".png");
            using (var stream = new FileStream(path, FileMode.CreateNew, FileAccess.Write, FileShare.None))
            {
                try { image.Save(stream, ImageFormat.Png); }
                catch { stream.Dispose(); File.Delete(path); throw; }
            }
            return path;
        }

        public static Bitmap Crop(Bitmap screen, Rectangle selection, GraphicsPath shape)
        {
            Rectangle area = Rectangle.Intersect(new Rectangle(Point.Empty, screen.Size), selection);
            if (area.Width < 1 || area.Height < 1) throw new ArgumentException("Select a non-empty screen area.");
            var result = new Bitmap(area.Width, area.Height, PixelFormat.Format32bppArgb);
            try
            {
                using (Graphics graphics = Graphics.FromImage(result))
                {
                    graphics.Clear(Color.Transparent);
                    if (shape != null)
                    {
                        using (var translated = (GraphicsPath)shape.Clone())
                        using (var matrix = new Matrix())
                        {
                            matrix.Translate(-area.X, -area.Y);
                            translated.Transform(matrix);
                            graphics.SetClip(translated);
                        }
                    }
                    graphics.DrawImage(screen, new Rectangle(Point.Empty, area.Size), area, GraphicsUnit.Pixel);
                }
                return result;
            }
            catch { result.Dispose(); throw; }
        }

        public static Bitmap Resize(Bitmap source, int width)
        {
            if (width < 1 || width > 16000) throw new ArgumentOutOfRangeException("width", "Width must be between 1 and 16000 pixels.");
            int height = Math.Max(1, (int)Math.Round(source.Height * (double)width / source.Width));
            if (height > 16000 || (long)width * height > 64000000) throw new ArgumentException("Resize would be too large. Choose a smaller width.");
            var result = new Bitmap(width, height, PixelFormat.Format32bppArgb);
            try
            {
                using (Graphics graphics = Graphics.FromImage(result))
                using (var attributes = new ImageAttributes())
                {
                    attributes.SetWrapMode(WrapMode.TileFlipXY);
                    graphics.CompositingMode = CompositingMode.SourceCopy;
                    graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
                    graphics.DrawImage(source, new Rectangle(0, 0, width, height), 0, 0, source.Width, source.Height, GraphicsUnit.Pixel, attributes);
                }
                return result;
            }
            catch { result.Dispose(); throw; }
        }
    }

    internal sealed class CaptureOverlay : Form
    {
        private readonly Bitmap screen;
        private readonly Rectangle desktop;
        private readonly string mode;
        private Point start;
        private bool dragging;
        private readonly System.Collections.Generic.List<Point> points = new System.Collections.Generic.List<Point>();
        private Rectangle selection;
        public Bitmap Result { get; private set; }
        public Color PickedColor { get; private set; }

        public CaptureOverlay(string captureMode)
        {
            mode = captureMode;
            desktop = SystemInformation.VirtualScreen;
            screen = new Bitmap(desktop.Width, desktop.Height, PixelFormat.Format32bppArgb);
            using (Graphics graphics = Graphics.FromImage(screen))
                graphics.CopyFromScreen(desktop.Location, Point.Empty, desktop.Size);
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.Manual;
            Bounds = desktop;
            TopMost = true;
            ShowInTaskbar = false;
            DoubleBuffered = true;
            KeyPreview = true;
            Cursor = Cursors.Cross;
            KeyDown += delegate(object sender, KeyEventArgs e) { if (e.KeyCode == Keys.Escape) { DialogResult = DialogResult.Cancel; Close(); } };
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            e.Graphics.DrawImageUnscaled(screen, 0, 0);
            using (var dim = new SolidBrush(Color.FromArgb(65, Color.Black)))
                e.Graphics.FillRectangle(dim, ClientRectangle);
            if (mode == "Freeform" && points.Count > 1)
            {
                using (var pen = new Pen(Color.DeepSkyBlue, 2)) e.Graphics.DrawLines(pen, points.ToArray());
            }
            else if (selection.Width > 0 && selection.Height > 0)
            {
                e.Graphics.DrawImage(screen, selection, selection, GraphicsUnit.Pixel);
                using (var pen = new Pen(Color.DeepSkyBlue, 2)) e.Graphics.DrawRectangle(pen, selection);
            }
            using (var font = new Font("Segoe UI", 12))
            {
                string instructions = mode == "Window" ? "Click a window" : mode == "Color" ? "Click a color" : "Drag to capture";
                Point cursor = PointToClient(System.Windows.Forms.Cursor.Position);
                var label = new Rectangle(Math.Max(0, Math.Min(Width - 330, cursor.X + 20)), Math.Max(0, Math.Min(Height - 42, cursor.Y + 25)), 330, 40);
                e.Graphics.FillRectangle(Brushes.Black, label);
                e.Graphics.DrawString(instructions + "  |  Esc cancels", font, Brushes.White, label.Location);
            }
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right) { DialogResult = DialogResult.Cancel; Close(); return; }
            if (e.Button != MouseButtons.Left) return;
            if (mode == "Color")
            {
                PickedColor = screen.GetPixel(e.X, e.Y);
                DialogResult = DialogResult.OK; Close(); return;
            }
            if (mode == "Window")
            {
                // Hide the overlay before looking up the actual window under it.
                Hide();
                Native.POINT location = new Native.POINT { X = e.X + desktop.X, Y = e.Y + desktop.Y };
                IntPtr window = Native.GetAncestor(Native.WindowFromPoint(location), 2);
                Native.RECT rect;
                if (window == IntPtr.Zero || !Native.GetWindowRect(window, out rect))
                    throw new InvalidOperationException("Could not determine the selected window.");
                selection = Rectangle.FromLTRB(rect.Left - desktop.X, rect.Top - desktop.Y, rect.Right - desktop.X, rect.Bottom - desktop.Y);
                Result = Images.Crop(screen, selection, null);
                DialogResult = DialogResult.OK; Close(); return;
            }
            start = e.Location; dragging = true; Capture = true;
            points.Clear(); points.Add(start);
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            if (dragging)
            {
                selection = Rectangle.FromLTRB(Math.Min(start.X, e.X), Math.Min(start.Y, e.Y), Math.Max(start.X, e.X), Math.Max(start.Y, e.Y));
                if (mode == "Freeform") points.Add(e.Location);
            }
            Invalidate();
        }

        protected override void OnMouseUp(MouseEventArgs e)
        {
            if (!dragging || e.Button != MouseButtons.Left) return;
            dragging = false; Capture = false;
            selection = Rectangle.FromLTRB(Math.Min(start.X, e.X), Math.Min(start.Y, e.Y), Math.Max(start.X, e.X), Math.Max(start.Y, e.Y));
            if (mode == "Freeform")
            {
                points.Add(e.Location);
                if (points.Count < 3) return;
                using (var path = new GraphicsPath())
                {
                    path.AddPolygon(points.ToArray());
                    selection = Rectangle.Ceiling(path.GetBounds());
                    if (selection.Width < 2 || selection.Height < 2) return;
                    Result = Images.Crop(screen, selection, path);
                }
            }
            else
            {
                if (selection.Width < 2 || selection.Height < 2) return;
                Result = Images.Crop(screen, selection, null);
            }
            DialogResult = DialogResult.OK; Close();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) screen.Dispose();
            base.Dispose(disposing);
        }
    }

    internal sealed class MainForm : Form
    {
        public const string Title = "Custom Snipping Tool";
        private readonly PictureBox preview = new PictureBox();
        private readonly TextBox text = new TextBox();
        private readonly Label status = new Label();
        private readonly Label bindings = new Label();
        private readonly NotifyIcon tray = new NotifyIcon();
        private readonly bool background;
        private Bitmap current;
        private string currentPath;
        private bool busy, exiting, keysEnabled = true;
        private IntPtr hook;
        private Native.HookProc hookProc;
        private bool shortcutRegistered;

        public MainForm(bool startInBackground)
        {
            background = startInBackground;
            Text = Title; Size = new Size(1050, 760); MinimumSize = new Size(790, 550);
            StartPosition = FormStartPosition.CenterScreen; Font = new Font("Segoe UI", 10);
            var layout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 5, Padding = new Padding(12) };
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 88));
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 32));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 130));
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 58));
            var toolbar = new FlowLayoutPanel { Dock = DockStyle.Fill, WrapContents = true };
            foreach (string mode in new[] { "Rectangle", "Freeform", "Window", "Full screen" })
            {
                string chosen = mode; AddButton(toolbar, chosen, delegate { CaptureScreen(chosen); });
            }
            AddButton(toolbar, "Copy image", CopyCurrent);
            AddButton(toolbar, "Extract text", async delegate { await ExtractText(); });
            AddButton(toolbar, "Resize", ResizeCurrent);
            AddButton(toolbar, "Pick color", delegate { CaptureScreen("Color"); });
            AddButton(toolbar, "Save clipboard text", SaveClipboardText);
            AddButton(toolbar, "Open Downloads", delegate { Process.Start("explorer.exe", "\"" + Images.Downloads() + "\""); });
            var pause = new CheckBox { Text = "Enable capture shortcuts", Checked = true, AutoSize = true, Margin = new Padding(8, 8, 3, 3) };
            pause.CheckedChanged += delegate { keysEnabled = pause.Checked; ConfigureKeys(); };
            toolbar.Controls.Add(pause);
            bindings.Dock = DockStyle.Fill;
            preview.Dock = DockStyle.Fill; preview.SizeMode = PictureBoxSizeMode.Zoom; preview.BackColor = Color.FromArgb(35, 35, 35);
            text.Dock = DockStyle.Fill; text.Multiline = true; text.ScrollBars = ScrollBars.Both; text.ReadOnly = true;
            status.Dock = DockStyle.Fill; status.Text = "Captures auto-save to Downloads and copy to clipboard. Close hides to tray; Exit stops the shortcuts.";
            layout.Controls.Add(toolbar, 0, 0); layout.Controls.Add(bindings, 0, 1);
            layout.Controls.Add(preview, 0, 2); layout.Controls.Add(text, 0, 3); layout.Controls.Add(status, 0, 4);
            Controls.Add(layout);
            var menu = new ContextMenuStrip();
            menu.Items.Add("Open screenshot tool", null, delegate { Show(); WindowState = FormWindowState.Normal; Activate(); });
            menu.Items.Add("Capture rectangle", null, delegate { CaptureScreen("Rectangle"); });
            menu.Items.Add("Open Downloads", null, delegate { Guard(delegate { Process.Start("explorer.exe", "\"" + Images.Downloads() + "\""); }); });
            menu.Items.Add("Exit and restore normal keys", null, delegate { exiting = true; Close(); });
            tray.Icon = SystemIcons.Application; tray.Text = Title; tray.ContextMenuStrip = menu; tray.Visible = true;
            tray.DoubleClick += delegate { Show(); WindowState = FormWindowState.Normal; Activate(); };
            Shown += delegate { ConfigureKeys(); if (background) Hide(); };
        }

        private void AddButton(FlowLayoutPanel panel, string label, Action action)
        {
            var button = new Button { Text = label, AutoSize = true, Height = 34, Padding = new Padding(6, 2, 6, 2) };
            button.Click += delegate { Guard(action); };
            panel.Controls.Add(button);
        }

        private void Guard(Action action)
        {
            try { action(); }
            catch (Exception ex) { Error(ex); }
        }

        private void Error(Exception ex)
        {
            status.Text = ex.Message;
            MessageBox.Show(this, ex.Message, "Could not complete action", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void ConfigureKeys()
        {
            if (shortcutRegistered) { Native.UnregisterHotKey(Handle, 1); shortcutRegistered = false; }
            if (hook != IntPtr.Zero) { Native.UnhookWindowsHookEx(hook); hook = IntPtr.Zero; }
            if (!keysEnabled) { bindings.Text = "Shortcuts paused. Shift + \\ and Print Screen work normally."; return; }
            shortcutRegistered = Native.RegisterHotKey(Handle, 1, 0x0004 | 0x4000, 0xDC);
            hookProc = KeyboardHook;
            hook = Native.SetWindowsHookEx(13, hookProc, Native.GetModuleHandle(null), 0);
            bindings.Text = "Shift + \\: " + (shortcutRegistered ? "capture" : "UNAVAILABLE (already assigned)") +
                "    Print Screen: " + (hook != IntPtr.Zero ? "capture" : "UNAVAILABLE") + "    Fn + Y: hardware-dependent";
            File.WriteAllText(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "hotkey-status.txt"), bindings.Text);
            if (!shortcutRegistered || hook == IntPtr.Zero)
                Error(new InvalidOperationException("Some capture shortcuts could not be installed. " + bindings.Text));
        }

        private IntPtr KeyboardHook(int code, IntPtr message, IntPtr data)
        {
            if (code >= 0)
            {
                Native.KBDLLHOOKSTRUCT key = (Native.KBDLLHOOKSTRUCT)Marshal.PtrToStructure(data, typeof(Native.KBDLLHOOKSTRUCT));
                if (key.VkCode == 0x2C && (key.Flags & 0x10) == 0 && Control.ModifierKeys == Keys.None)
                {
                    if (message.ToInt32() == 0x101 && !busy)
                        BeginInvoke((Action)delegate { Guard(delegate { CaptureScreen("Rectangle"); }); });
                    return new IntPtr(1);
                }
            }
            return Native.CallNextHookEx(hook, code, message, data);
        }

        protected override void WndProc(ref Message message)
        {
            if (message.Msg == 0x0312 && message.WParam.ToInt32() == 1 && !busy)
                BeginInvoke((Action)delegate { Guard(delegate { CaptureScreen("Rectangle"); }); });
            base.WndProc(ref message);
        }

        private void ClipboardAction(Action action)
        {
            for (int attempt = 0; ; attempt++)
            {
                try { action(); return; }
                catch (ExternalException) { if (attempt >= 4) throw; Thread.Sleep(100); }
            }
        }

        private void SetCurrent(Bitmap image, string path)
        {
            Bitmap old = current; current = image; currentPath = path; preview.Image = current;
            if (old != null) old.Dispose();
            text.Clear(); status.Text = "Saved " + image.Width + " x " + image.Height + " PNG: " + path;
        }

        private void CaptureScreen(string mode)
        {
            if (busy) return;
            busy = true;
            try
            {
                Hide();
                // Let the desktop compositor remove this window before freezing the screen.
                Application.DoEvents(); Thread.Sleep(200);
                if (mode == "Full screen")
                {
                    Rectangle desktop = SystemInformation.VirtualScreen;
                    using (var image = new Bitmap(desktop.Width, desktop.Height))
                    {
                        using (Graphics graphics = Graphics.FromImage(image)) graphics.CopyFromScreen(desktop.Location, Point.Empty, desktop.Size);
                        SaveCapture(new Bitmap(image));
                    }
                }
                else
                {
                    using (var overlay = new CaptureOverlay(mode))
                    {
                        if (overlay.ShowDialog() == DialogResult.OK)
                        {
                            if (mode == "Color")
                            {
                                Color color = overlay.PickedColor;
                                string hex = "#" + color.R.ToString("X2") + color.G.ToString("X2") + color.B.ToString("X2");
                                ClipboardAction(delegate { Clipboard.SetText(hex); });
                                text.Text = hex + Environment.NewLine + "RGB(" + color.R + ", " + color.G + ", " + color.B + ")";
                                status.Text = "Color copied to clipboard: " + hex;
                            }
                            else SaveCapture(overlay.Result);
                        }
                    }
                }
            }
            finally { busy = false; Show(); WindowState = FormWindowState.Normal; Activate(); }
        }

        private void SaveCapture(Bitmap image)
        {
            string path;
            try { path = Images.Save(image, Images.Downloads(), "Snip"); }
            catch { image.Dispose(); throw; }
            SetCurrent(image, path);
            try { ClipboardAction(delegate { Clipboard.SetImage(current); }); }
            catch (ExternalException ex) { throw new InvalidOperationException("The PNG was saved at " + path + ", but clipboard copying failed. Use Copy image to retry.", ex); }
        }

        private void RequireImage()
        {
            if (current == null) throw new InvalidOperationException("Capture a screenshot first.");
        }

        private void CopyCurrent()
        {
            RequireImage(); ClipboardAction(delegate { Clipboard.SetImage(current); });
            status.Text = "Image copied to clipboard. Saved file: " + currentPath;
        }

        private void ResizeCurrent()
        {
            RequireImage();
            using (var dialog = new Form { Text = "Resize a copy (original is preserved)", Size = new Size(410, 160), FormBorderStyle = FormBorderStyle.FixedDialog, StartPosition = FormStartPosition.CenterParent, MinimizeBox = false, MaximizeBox = false })
            {
                var label = new Label { Text = "Width in pixels (aspect ratio is preserved):", AutoSize = true, Location = new Point(12, 12) };
                var width = new NumericUpDown { Minimum = 1, Maximum = 16000, Value = Math.Min(current.Width, 16000), Location = new Point(12, 42), Width = 160 };
                var save = new Button { Text = "Save resized copy", DialogResult = DialogResult.OK, AutoSize = true, Location = new Point(195, 40) };
                dialog.Controls.AddRange(new Control[] { label, width, save }); dialog.AcceptButton = save;
                if (dialog.ShowDialog(this) == DialogResult.OK) SaveCapture(Images.Resize(current, (int)width.Value));
            }
        }

        private async Task ExtractText()
        {
            if (busy) return;
            try
            {
                RequireImage(); busy = true; status.Text = "Extracting text locally with Windows OCR...";
                string imagePath = currentPath;
                string output = await Task.Run(delegate
                {
                    string script = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Read-ScreenshotText.ps1");
                    var info = new ProcessStartInfo(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), @"WindowsPowerShell\v1.0\powershell.exe"),
                        "-NoProfile -NonInteractive -ExecutionPolicy Bypass -File \"" + script + "\" -ImagePath \"" + imagePath + "\"");
                    info.UseShellExecute = false; info.CreateNoWindow = true; info.RedirectStandardOutput = true; info.RedirectStandardError = true;
                    info.StandardOutputEncoding = Encoding.UTF8; info.StandardErrorEncoding = Encoding.UTF8;
                    using (Process process = Process.Start(info))
                    {
                        Task<string> stdout = process.StandardOutput.ReadToEndAsync();
                        Task<string> stderr = process.StandardError.ReadToEndAsync();
                        if (!process.WaitForExit(60000)) { process.Kill(); process.WaitForExit(); throw new TimeoutException("Windows OCR timed out. Try a smaller screenshot."); }
                        Task.WaitAll(stdout, stderr);
                        if (process.ExitCode != 0) throw new InvalidOperationException("Windows OCR failed: " + stderr.Result.Trim());
                        return stdout.Result;
                    }
                });
                text.Text = output;
                if (String.IsNullOrWhiteSpace(output)) { status.Text = "No readable text found. Try a closer or clearer capture."; return; }
                ClipboardAction(delegate { Clipboard.SetText(output); });
                status.Text = "Extracted text copied to clipboard. Use Save clipboard text to save it.";
            }
            catch (Exception ex) { Error(ex); }
            finally { busy = false; }
        }

        private void SaveClipboardText()
        {
            string value = null;
            ClipboardAction(delegate { if (Clipboard.ContainsText()) value = Clipboard.GetText(); });
            if (String.IsNullOrEmpty(value)) throw new InvalidOperationException("There is no text on the clipboard. Copy text or use Extract text first.");
            string path = Images.NewPath(Images.Downloads(), "Clipboard", ".txt");
            using (var stream = new FileStream(path, FileMode.CreateNew, FileAccess.Write, FileShare.None))
            using (var writer = new StreamWriter(stream, new UTF8Encoding(false))) writer.Write(value);
            text.Text = value; status.Text = "Clipboard text saved: " + path;
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (!exiting && e.CloseReason == CloseReason.UserClosing) { e.Cancel = true; Hide(); return; }
            if (shortcutRegistered) Native.UnregisterHotKey(Handle, 1);
            if (hook != IntPtr.Zero) Native.UnhookWindowsHookEx(hook);
            tray.Visible = false; tray.Dispose(); preview.Image = null;
            if (current != null) current.Dispose();
            base.OnFormClosing(e);
        }
    }

    internal static class Native
    {
        internal delegate IntPtr HookProc(int code, IntPtr message, IntPtr data);
        [StructLayout(LayoutKind.Sequential)] internal struct POINT { public int X, Y; }
        [StructLayout(LayoutKind.Sequential)] internal struct RECT { public int Left, Top, Right, Bottom; }
        [StructLayout(LayoutKind.Sequential)] internal struct KBDLLHOOKSTRUCT { public uint VkCode, ScanCode, Flags, Time; public IntPtr ExtraInfo; }
        [DllImport("user32.dll", SetLastError = true)] internal static extern bool RegisterHotKey(IntPtr handle, int id, uint modifiers, uint key);
        [DllImport("user32.dll")] internal static extern bool UnregisterHotKey(IntPtr handle, int id);
        [DllImport("user32.dll", SetLastError = true)] internal static extern IntPtr SetWindowsHookEx(int id, HookProc callback, IntPtr module, uint thread);
        [DllImport("user32.dll")] internal static extern bool UnhookWindowsHookEx(IntPtr hook);
        [DllImport("user32.dll")] internal static extern IntPtr CallNextHookEx(IntPtr hook, int code, IntPtr message, IntPtr data);
        [DllImport("kernel32.dll", CharSet = CharSet.Auto)] internal static extern IntPtr GetModuleHandle(string name);
        [DllImport("user32.dll")] internal static extern IntPtr WindowFromPoint(POINT point);
        [DllImport("user32.dll")] internal static extern IntPtr GetAncestor(IntPtr window, uint flag);
        [DllImport("user32.dll")] internal static extern bool GetWindowRect(IntPtr window, out RECT rectangle);
        [DllImport("user32.dll", CharSet = CharSet.Unicode)] internal static extern IntPtr FindWindow(string className, string title);
        [DllImport("user32.dll")] internal static extern bool ShowWindow(IntPtr window, int command);
        [DllImport("user32.dll")] internal static extern bool SetForegroundWindow(IntPtr window);
    }

    internal static class SelfTest
    {
        private static void Check(bool condition, string message) { if (!condition) throw new Exception(message); }
        internal static void Run()
        {
            string folder = Path.Combine(Path.GetTempPath(), "CustomSnipTest-" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(folder);
            var files = new System.Collections.Generic.List<string>();
            try
            {
                using (var image = new Bitmap(100, 60))
                {
                    using (Graphics graphics = Graphics.FromImage(image)) graphics.Clear(Color.Red);
                    using (var crop = Images.Crop(image, new Rectangle(10, 10, 20, 15), null))
                        Check(crop.Size == new Size(20, 15) && crop.GetPixel(5, 5).ToArgb() == Color.Red.ToArgb(), "Rectangle crop failed.");
                    using (var crop = Images.Crop(image, new Rectangle(-10, -10, 30, 30), null))
                        Check(crop.Size == new Size(20, 20), "Off-screen window bounds failed.");
                    using (var path = new GraphicsPath())
                    {
                        path.AddPolygon(new[] { new Point(0, 0), new Point(40, 0), new Point(0, 40) });
                        using (var crop = Images.Crop(image, new Rectangle(0, 0, 40, 40), path))
                            Check(crop.GetPixel(3, 3).R == 255 && crop.GetPixel(35, 35).A == 0, "Freeform transparent crop failed.");
                    }
                    using (var resized = Images.Resize(image, 50))
                        Check(resized.Size == new Size(50, 30), "Aspect-ratio resize failed.");
                    bool invalid = false;
                    try { Images.Resize(image, 0); } catch (ArgumentOutOfRangeException) { invalid = true; }
                    Check(invalid, "Invalid resize was accepted.");
                    files.Add(Images.Save(image, folder, "Snip")); files.Add(Images.Save(image, folder, "Snip"));
                    Check(files[0] != files[1], "Save filename collision.");
                    using (var loaded = new Bitmap(files[0]))
                        Check(loaded.Size == image.Size && loaded.RawFormat.Guid == ImageFormat.Png.Guid, "PNG save failed.");
                    Check(Directory.Exists(Images.Downloads()), "Downloads detection failed.");
                }
                File.WriteAllText(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "self-test-result.txt"),
                    "PASS: Rectangle crop, off-screen window clipping, freeform transparency, resize aspect ratio, invalid resize rejection, unique PNG saves, PNG roundtrip, and Downloads detection.");
            }
            finally { foreach (string file in files) File.Delete(file); Directory.Delete(folder); }
        }
    }
}
